<template>
  <Tag color="blue">
    {{data}}
  </Tag>
</template>

<script>
    export default {
      props:{
        data:String
      }
    }
</script>
