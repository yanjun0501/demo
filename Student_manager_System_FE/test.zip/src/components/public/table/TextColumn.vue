<template>
  <Span style="font-size:16px;">
    {{data}}
  </Span>
</template>

<script>
  export default {
    props:{
      data:String
    }
  }
</script>
