<template>
  <span>error page</span>
</template>

<script>
    export default {}
</script>
