<template>
  <div>
    <transition>
      <router-view></router-view>
    </transition>
  </div>
</template>
